
  # Premium Responsive Design

  This is a code bundle for Premium Responsive Design. The original project is available at https://www.figma.com/design/t251kbkItecBEaihRdjM0o/Premium-Responsive-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  