import { createBrowserRouter } from "react-router";
import { LandingPage } from "./pages/LandingPage";
import { LoginPage } from "./pages/LoginPage";
import { RegisterPage } from "./pages/RegisterPage";
import { DashboardLayout } from "./pages/DashboardLayout";
import { FeedPage } from "./pages/FeedPage";
import { ProfilePage } from "./pages/ProfilePage";
import { MessagesPage } from "./pages/MessagesPage";
import { EventsPage } from "./pages/EventsPage";
import { JobsPage } from "./pages/JobsPage";
import { MarketplacePage } from "./pages/MarketplacePage";
import { AdminDashboard } from "./pages/AdminDashboard";
import { NotFound } from "./pages/NotFound";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: LandingPage,
  },
  {
    path: "/login",
    Component: LoginPage,
  },
  {
    path: "/register",
    Component: RegisterPage,
  },
  {
    path: "/dashboard",
    Component: DashboardLayout,
    children: [
      { index: true, Component: FeedPage },
      { path: "profile", Component: ProfilePage },
      { path: "messages", Component: MessagesPage },
      { path: "events", Component: EventsPage },
      { path: "jobs", Component: JobsPage },
      { path: "marketplace", Component: MarketplacePage },
      { path: "admin", Component: AdminDashboard },
    ],
  },
  {
    path: "*",
    Component: NotFound,
  },
]);
